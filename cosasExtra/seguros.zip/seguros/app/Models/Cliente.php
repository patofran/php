<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory;

    protected $fillable = [
        'dni',
        'nombre',
        'apellidos',
        'telefono',
    ];

    public function vehiculos()
    {
        return $this->hasMany(Vehiculo::class, 'id');  //un cliente puede tener muchos vehiculos
    }
}
