@extends('layouts.plantilla')
@section('content')

<h1>Bienvenido a la página principal</h1>





@stop