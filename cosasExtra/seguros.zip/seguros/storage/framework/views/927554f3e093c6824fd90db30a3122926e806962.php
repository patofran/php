
<?php $__env->startSection('content'); ?>

<h1>Listado de Siniestros</h1>

<table style="border: 1px solid black; border-collapse: collapse;">
    <thead>
        <tr>
            <th style="border: 1px solid black; padding: 8px;">Codigo de la poliza</th>
            <th style="border: 1px solid black; padding: 8px;">Comunidad</th>
            <th style="border: 1px solid black; padding: 8px;">Provincia</th>
            <th style="border: 1px solid black; padding: 8px;">Documento</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $siniestros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siniestro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($siniestro->idPol); ?></a></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($siniestro->comunidad); ?></a></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($siniestro->provincia); ?></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($siniestro->documento); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<p>
    <h3>¿Deseas añadir un siniestro nuevo?</h3>
    <a href="<?php echo e(route('siniestros.create')); ?>">Añadir un siniestro nuevo</a><p>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/siniestros/index.blade.php ENDPATH**/ ?>