
<?php $__env->startSection('content'); ?>

<h2>Edita el cliente</h2>
<form action="<?php echo e(route('clientes.update', ['id' => $cliente->id])); ?>" method="POST">

  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
  <div class="mb-3 col-8">
    <label class="form-label">DNI: 
    <input type="text" class="form-control" name="dni" value="<?php echo e($cliente->dni); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo dni no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <p>
  <div class="mb-3 col-8">
    <label class="form-label">Nombre: 
    <input type="text" class="form-control" name="nombre" value="<?php echo e($cliente->nombre); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo nombre no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
<p>
  <div class="mb-3 col-8">
    <label class="form-label">Apellidos: </label>
    <input type="text"  class="form-control" name="apellidos" value="<?php echo e($cliente->apellidos); ?>">
  </div>
  <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span>*El campo apellidos no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
<p>
  <div class="mb-3 col-8">
      <label class="form-label">Telefono: </label>
      <input type="text" class="form-control" name="telefono" value="<?php echo e($cliente->telefono); ?>">
  </div>
  <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo telefono no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
<p>
  <button type="submit" class="btn btn-primary" style="padding:7px;">Guardar Cambios</button>
</form>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/clientes/edit.blade.php ENDPATH**/ ?>