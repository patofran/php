
<?php $__env->startSection('content'); ?>

<h2>Edita el cliente</h2>
<form action="<?php echo e(route('polizas.update', $poliza)); ?>" method="POST">

  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
  <div class="mb-3 col-8">
    <label class="form-label">Codigo del vehiculo: 
    <input type="text" class="form-control" name="idVehi" value="<?php echo e($poliza->idVehi); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['idVehi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo del codigo del vehiculo no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <p>
  <div class="mb-3 col-8">
    <label class="form-label">Importe: 
    <input type="text" class="form-control" name="importe" value="<?php echo e($poliza->importe); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['importe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo importe no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
<p>
  <div class="mb-3 col-8">
    <label class="form-label">Fecha de caducidad: </label>
    <input type="text"  class="form-control" name="fecha_cad" value="<?php echo e($poliza->fecha_cad); ?>">
  </div>
  <?php $__errorArgs = ['fecha_cad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo de fecha de caducidad no puede estar vacío</span> 
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
  
<p>
  <button type="submit" class="btn btn-primary" style="padding:7px;">Guardar Cambios</button>
</form>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/polizas/edit.blade.php ENDPATH**/ ?>