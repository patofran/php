
<?php $__env->startSection('content'); ?>

    <h1>¿Desea eliminar el registro?</h1>
    <h3>Nombre: <?php echo e($cliente->nombre); ?></h3>
    <h3>Apellido: <?php echo e($cliente->apellidos); ?></h3>
    <h3>Telefono: <?php echo e($cliente->telefono); ?></h3>
  
    
 
        <form action="<?php echo e(route('clientes.delete', $cliente)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" style="padding:7px;">Eliminar</button>
        </form>
        <p>
            <form action="<?php echo e(route('clientes.index')); ?>">
                <button type="submit" style="padding:7px;"> << Volver</button>
            </form>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/clientes/show.blade.php ENDPATH**/ ?>