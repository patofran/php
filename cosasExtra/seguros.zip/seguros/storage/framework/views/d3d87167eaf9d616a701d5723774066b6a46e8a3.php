
<?php $__env->startSection('content'); ?>

<h1>Listado de Vehiculos</h1>

<table style="border: 1px solid black; border-collapse: collapse;">
    <thead>
        <tr>
            <th style="border: 1px solid black; padding: 8px;">Codigo del Cliente</th>
            <th style="border: 1px solid black; padding: 8px;">Marca</th>
            <th style="border: 1px solid black; padding: 8px;">Modelo</th>
            <th style="border: 1px solid black; padding: 8px;">Matricula</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid black; padding: 8px;"><a href="<?php echo e(route('vehiculos.show', $vehiculo->id)); ?>"><?php echo e($vehiculo->idCli); ?></a></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($vehiculo->marca); ?></a></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($vehiculo->modelo); ?></td>
                <td style="border: 1px solid black; padding: 8px;"><?php echo e($vehiculo->matricula); ?></td>
                <td> <form method="GET" action="<?php echo e(route('vehiculos.edit', $vehiculo)); ?>">
                    <button type="submit" style="padding:7px;margin:2%; background-color:rgb(210, 238, 196);">Editar</button>
                </form></td>
                <td> <form method="GET" action="<?php echo e(route('vehiculos.show', $vehiculo)); ?>">
                    <button type="submit" style="padding:7px; margin:2%; background-color:rgb(238, 202, 196);">Eliminar</button>
                </form></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<p>
    <h3 style="margin:1%; margin-top:2%;">Añadir un nuevo Vehiculo</h3>
    <form method="GET" action="<?php echo e(route('vehiculos.create')); ?>">
        <button type="submit" style="padding:7px; margin:1%; width:10%; background-color:rgb(238, 235, 196);">Añadir</button>
    </form>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/vehiculos/index.blade.php ENDPATH**/ ?>