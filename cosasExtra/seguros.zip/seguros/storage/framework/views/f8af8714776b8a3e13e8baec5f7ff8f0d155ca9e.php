
<?php $__env->startSection('content'); ?>

    <h1>¿Desea eliminar el vehiculo?</h1>
    <h3>Codigo del cliente: <?php echo e($vehiculo->idCli); ?></h3>
    <h3>Marca: <?php echo e($vehiculo->marca); ?></h3>
    <h3>Modelo: <?php echo e($vehiculo->modelo); ?></h3>
    <h3>Matricula: <?php echo e($vehiculo->matricula); ?></h3>
  
    
        <form action="<?php echo e(route('vehiculos.delete', $vehiculo)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" style="padding:7px;">Eliminar</button>
        </form>
        <p>
        <form action="<?php echo e(route('vehiculos.index')); ?>">
            <button type="submit" style="padding:7px;"> << Volver</button>
        </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/vehiculos/show.blade.php ENDPATH**/ ?>