
<?php $__env->startSection('content'); ?>

    <h1>Añadir una nueva poliza</h1>
    <form action="<?php echo e(route('polizas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Codigo del vehiculo: 
            <input type="text" name="idVehi" value="<?php echo e(old('idVehi')); ?>">
        </label>
        <?php $__errorArgs = ['idVehi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span style='color:red'>*El campo del codigo del vehiculo no puede estar vacío</span> 
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Importe: 
            <input type="text" name="importe" value="<?php echo e(old('importe')); ?>">
        </label>
        <?php $__errorArgs = ['importe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo importe no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <p>
        <label>Fecha de caducidad: 
            <input type="text" name="fecha_cad" value=<?php echo e(old('fecha_cad')); ?>>
        </label>
        <?php $__errorArgs = ['fecha_cad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo fecha_cad no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p>
         
            <p>
        <button type="submit">Añadir</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/polizas/create.blade.php ENDPATH**/ ?>