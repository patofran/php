
<?php $__env->startSection('content'); ?>

<h2>Edita el vehiculo</h2>
<form action="<?php echo e(route('vehiculos.update', ['id' => $vehiculo->id])); ?>" method="POST">

  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
  <div class="mb-3 col-8">
    <label class="form-label">Codigo del cliente: 
    <input type="text" class="form-control" name="idCli" value="<?php echo e($vehiculo->idCli); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['idCli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo del codigo del cliente no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <p>
  <div class="mb-3 col-8">
    <label class="form-label">Marca: 
    <input type="text" class="form-control" name="marca" value="<?php echo e($vehiculo->marca); ?>">
  </label>
  </div>
  <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo marca no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
<p>
  <div class="mb-3 col-8">
    <label class="form-label">Modelo: </label>
    <input type="text"  class="form-control" name="modelo" value="<?php echo e($vehiculo->modelo); ?>">
  </div>
  <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span>*El campo modelo no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 
<p>
  <div class="mb-3 col-8">
      <label class="form-label">Matricula: </label>
      <input type="text" class="form-control" name="matricula" value="<?php echo e($vehiculo->matricula); ?>">
  </div>
  <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <br>
  <span style='color:red'>*El campo matricula no puede estar vacío</span>  
  </br> 
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
<p>
  <button type="submit" class="btn btn-primary" style="padding:7px;">Guardar Cambios</button>
</form>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/vehiculos/edit.blade.php ENDPATH**/ ?>