
<?php $__env->startSection('content'); ?>

    <h1>Añadir un nuevo vehiculo</h1>
    <form action="<?php echo e(route('vehiculos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Codigo del cliente: 
            <input type="text" name="idCli" value="<?php echo e(old('idCli')); ?>">
        </label>
        <?php $__errorArgs = ['idCli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span style='color:red'>*El campo del codigo del cliente no puede estar vacío</span> 
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Marca: 
            <input type="text" name="marca" value="<?php echo e(old('marca')); ?>">
        </label>
        <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo marca no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <p>
        <label>Modelo: 
            <input type="text" name="modelo" value=<?php echo e(old('modelo')); ?>>
        </label>
        <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo modelo no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p>
            <label>Matricula: 
                <input type="text" name="matricula" value=<?php echo e(old('matricula')); ?>>
            </label>
            <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <span>*El campo matricula no puede estar vacío</span>  
            </br> 
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p>
        <button type="submit" style="padding:7px; ">Añadir</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/vehiculos/create.blade.php ENDPATH**/ ?>