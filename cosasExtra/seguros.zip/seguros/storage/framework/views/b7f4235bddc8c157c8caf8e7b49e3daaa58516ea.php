
<?php $__env->startSection('content'); ?>

<h1>Bienvenido a la página principal</h1>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/home.blade.php ENDPATH**/ ?>