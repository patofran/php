
<?php $__env->startSection('content'); ?>

    <h1>Añadir un nuevo siniestro</h1>
    <form action="<?php echo e(route('siniestros.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Codigo de la poliza: 
            <input type="text" name="idPol" value="<?php echo e(old('idPol')); ?>">
        </label>
        <?php $__errorArgs = ['idPol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span style='color:red'>*El campo del codigo del vehiculo no puede estar vacío</span> 
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Comunidad: 
            <input type="text" name="comunidad" value="<?php echo e(old('comunidad')); ?>">
        </label>
        <?php $__errorArgs = ['comunidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo comunidad no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <p>
        <label>Provincia: 
            <input type="text" name="provincia" value=<?php echo e(old('provincia')); ?>>
        </label>
        <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*El campo provincia no puede estar vacío</span>  
        </br> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p>

            <p>
                <label>Documento: 
                    <input type="text" name="documento" value=<?php echo e(old('documento')); ?>>
                </label>
                <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <span>*El campo provincia no puede estar vacío</span>  
                </br> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p>
         
            <p>
        <button type="submit">Añadir</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\seguros\resources\views/siniestros/create.blade.php ENDPATH**/ ?>